package com.example.acviewchange.acview.AcView28c96;

import com.example.acviewchange.acview.AcViewBaseModel;
import com.example.acviewchange.dataimp.OnRequestListener;
import com.example.annotation.AcView.annotation.AcViewModelAnnotation;

//@AcViewModelAnnotation("28c96")
public class AcView28c96Model extends AcViewBaseModel<String> {
    public AcView28c96Model(String mid) {
        super(mid);
    }

    @Override
    public void sendPowCmd(OnRequestListener<String> listener) {

    }
}
