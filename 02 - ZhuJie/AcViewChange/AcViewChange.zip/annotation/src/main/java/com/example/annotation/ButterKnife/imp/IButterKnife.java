package com.example.annotation.ButterKnife.imp;

public interface IButterKnife<T> {
    void bind(T target);
}
