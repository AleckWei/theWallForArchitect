package com.example.acviewchange.recyclerview.viewholder;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class HomeItemViewHolder extends RecyclerView.ViewHolder {
    public HomeItemViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
