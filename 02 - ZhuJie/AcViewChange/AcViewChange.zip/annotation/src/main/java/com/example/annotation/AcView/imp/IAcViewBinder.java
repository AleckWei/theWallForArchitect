package com.example.annotation.AcView.imp;

public interface IAcViewBinder<T> {
    void bindPresenter(T target, String mid);
}
