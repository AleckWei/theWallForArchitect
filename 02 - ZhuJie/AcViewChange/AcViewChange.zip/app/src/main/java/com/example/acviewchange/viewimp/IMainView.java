package com.example.acviewchange.viewimp;

/**
 * 主页的页面刷新接口
 */
public interface IMainView {

}
