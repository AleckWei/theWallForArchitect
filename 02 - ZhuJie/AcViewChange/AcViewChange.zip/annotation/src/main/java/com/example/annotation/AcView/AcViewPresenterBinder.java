package com.example.annotation.AcView;

/**
 * 绑定presenter 和 model
 */
public class AcViewPresenterBinder {
    public static void bind(Object target) {

    }
}
