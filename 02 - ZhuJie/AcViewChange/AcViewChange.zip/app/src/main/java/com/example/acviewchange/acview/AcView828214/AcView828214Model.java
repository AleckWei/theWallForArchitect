package com.example.acviewchange.acview.AcView828214;

import com.example.acviewchange.acview.AcViewBaseModel;
import com.example.acviewchange.dataimp.OnRequestListener;
import com.example.annotation.AcView.annotation.AcViewModelAnnotation;

@AcViewModelAnnotation("828214")
public class AcView828214Model extends AcViewBaseModel<String> {
    public AcView828214Model(String mid) {
        super(mid);
    }

    @Override
    public void sendPowCmd(OnRequestListener<String> listener) {

    }
}
