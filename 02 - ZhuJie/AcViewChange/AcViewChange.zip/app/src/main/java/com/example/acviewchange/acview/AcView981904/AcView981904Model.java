package com.example.acviewchange.acview.AcView981904;

import com.example.acviewchange.acview.AcViewBaseModel;
import com.example.acviewchange.dataimp.OnRequestListener;
import com.example.annotation.AcView.annotation.AcViewModelAnnotation;

@AcViewModelAnnotation("981904")
public class AcView981904Model extends AcViewBaseModel<String> {
    public AcView981904Model(String mid) {
        super(mid);
    }

    @Override
    public void sendPowCmd(OnRequestListener<String> listener) {

    }
}
